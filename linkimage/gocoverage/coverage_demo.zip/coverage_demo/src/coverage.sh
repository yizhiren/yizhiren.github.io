set -e

profile="coverage.out"
mergecover="merge_cover"
mode="count"

for package in $(go list ./...|grep -v src); do
    coverfile="$(echo $package | tr / -).cover"
    go test -covermode="$mode" -coverprofile="$coverfile" -coverpkg=./... "$package"
done
go test -covermode="$mode" -coverprofile=current.cover -coverpkg=./... ./

grep -h -v "^mode:" *.cover | sort > $mergecover

echo "mode: $mode" > $profile
current=""
count=0
while read line; do
    block=$(echo $line | cut -d ' ' -f1-2)
    num=$(echo $line | cut -d ' ' -f3)
    if [ "$current" == "" ]; then
        current=$block
        count=$num
    elif [ "$block" == "$current" ]; then
        count=$(($count + $num))
    else
        echo $current $count >> $profile
        current=$block
        count=$num
    fi
done < $mergecover

if [ "$current" != "" ]; then
    echo $current $count >> $profile
fi
